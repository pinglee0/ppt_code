package lesson1;

public class example {
    public static void main(String[] args){
        System.out.println("Hello world!");
    }
}
class  example2 {
    public static void main(String[] args){
        System.out.println("Hello world!2");
        System.out.println(args);
        System.out.println(args[0]);
    }
}
class example3 {
    static int a;
    int b=1;
    public static void main(String[] args){
        System.out.println("Hello world!");
        System.out.println(a);
        a=2;
        System.out.println(a);
//        System.out.println(b);
        example3 b1=new example3();
        System.out.println(b1.b);
    }
}
class Welcome{
    public static void main(String[] args){
        System.out.println("Hi there!");
        System.out.println("lesson1.Welcome to APCS A!");
    }
}
class SecondClass{
    public static void main(String[] args){
        System.out.print("Hi there!");
        System.out.println("lesson1.Welcome to APCS A!");
        System.out.print("We will learn Java!");
    }
}
class BaWitDaBa {
    /* Suzy Student, CS 101, Fall 2019
   This program prints lyrics about ... something. */
    public static void main(String[] args) {
        // first verse
        System.out.println("Bawitdaba");
        System.out.println("da bang a dang diggy diggy");
//        System.out.println("da bang a dang diggy diggy");
        System.out.println();
        // second verse
        System.out.println("diggy said the boogy");
        System.out.println("said up jump the boogy");
    }
}
class lab1 {
    public static void main(String[] args) {
        System.out.print("JAVA is a programming language.\nBasic Java syntax.\n\n");

        System.out.println("JAVA is a programming language.");
        System.out.println( "Basic Java syntax.");
    }
}


