package lesson1;
//理解 public 理解static
//1、private，私有的访问权限，也是最严格的访问权限，仅只能在设置了该权限的类中访问，利用这个访问权限，表现出封装思想。
//2、default，默认的访问权限，也是可以省略的访问权限，它不仅能在设置了该权限的类中访问，也可以在同一包中的类或子类中访问。
//3、protected，受保护的访问权限，它除了具有default的访问权限外，还可以在不同包中所继承的子类访问。
//4、public，公有的访问权限，也是最宽松的访问权限，不仅可以是同一个类或子类，还是同一个包中的类或子类，又还是不同包中的类或子类，都可以访问。
import pack1.try1;
public class example4 {
        public static void main(String[] args){
            System.out.println("Hello world!");
            try1.print1();
//            int num=a.add2(2.5,1);
//            int num2=try1.add1(2.5,1);
            //调用非static静态方法 需要实例化
            try1 a=new try1();
            System.out.println(a.add1(2.5,1));
            //System.out.println(a.add2(2.5,1));
        }
}