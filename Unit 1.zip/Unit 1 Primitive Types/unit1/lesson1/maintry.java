package lesson1;
//理解main函数输入String[]
public class maintry {
    public static void main(String[] args){
        String[] a={"class1"};
        example.main(a);
        example2.main(a);
    }
}
