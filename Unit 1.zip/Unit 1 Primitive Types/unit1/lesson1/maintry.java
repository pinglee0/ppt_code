package lesson1;

public class maintry {
    public static void main(String[] args){
        String[] a={"class1"};
        example.main(a);
        example2.main(a);
    }
}
