package lesson2;

class example2 {
    public static void main(String[] args) {
        // Calculate total owed, assuming 8% tax / 15% tip
        double grade = (95.1 + 71.9 + 82.6) / 3.0;
        System.out.println("Your grade was " + grade);

        int students = 11 + 17 + 4 + 19 + 14;
        System.out.println("There are " + students +
                " students in the course.");
    }
}
public class example {
    public static void main(String[] args) {
        // Calculate total owed, assuming 8% tax / 15% tip
        System.out.print("Subtotal:");
        System.out.println(38 + 40 + 30);
        System.out.print("Tax:");
        System.out.println((38 + 40 + 30) * .08);
        System.out.print("Tip:");
        System.out.println((38 + 40 + 30) * .15);
        System.out.print("Total:");
        System.out.println(38 + 40 + 30 +
                (38 + 40 + 30) * .08 +
                (38 + 40 + 30) * .15);
        System.out.println("");
        int a=38 + 40 + 30;
        System.out.println("Subtotal:"+a+"\nTax:"+a*.08+"\nTip:"+a*.15+"\nTotal:"+(a+a*.08+a*.15));
        System.out.println("");
        System.out.println("Subtotal:"+a+"\nTax:"+a*.08+"\nTip:"+a*.15+"\nTotal:"+a+a*.08+a*.15);
        System.out.println("");
        System.out.println(3+1.5*2);
    }
}
class example3 {
    public static void main(String[] args) {
        int age = 22;
        boolean minor = (age < 21);
        boolean lovesAPCS = true;
        System.out.println(minor); // false
        System.out.println(lovesAPCS); // true
    }
}
class TestFinal
{
    public static void main(String[] args)   {
        final double PI = 3.14;
        System.out.println(PI);
//        PI = 4.2; // This will cause a syntax error
//        int private=1;
//        double short  =2.1;
//        String double="try1";
    }
}
class lab1{
    public static void main(String[] args)   {
        boolean isTure =false;
        double money=9.99;
        System.out.print(money);
        System.out.println(isTure);
    }
}
class lab2{
    public static void main(String[] args)   {
        String name="Chen";
        int age=50;
        int iq=2*25;
        System.out.println(name+age+"\n"+iq);
    }
}
class lab3{
    public static void main(String[] args)   {
        String fristName;
        String lastName;
        fristName="Bob";
        lastName="Jones";
        System.out.println(fristName);
        System.out.print(lastName);
    }
}
