package lesson3;
import java.math.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class example {
    public static void main(String[] args){
        System.out.println(3 * 4);
        System.out.println("3 * 4");
        System.out.println(14 / 4);
        int a1=14,a2=4;
        double a3=14,a4=4;
        System.out.println(a3+"\t"+a4);
        System.out.println(a1 / a2+"    "+(double)a1/(double)a2+"\n"+a3/a4+"    "+(int)a3/(int)a4);
        System.out.println(a1%a2==(a1-(a1/a2)*a2));
        System.out.println(a3%a4+"  "+a3/a4);
//        System.out.println(11/0);
        System.out.println(-21 % 4);
        System.out.println(21 % -4);
        int num=32;
        if (num%2==0){
            System.out.println(num+" is an even number");
        }
        System.out.println((1 * 2 + 3 * 5 % 4)+"\n"+(1 + 8 % 3 * 2 - 9));
        System.out.println((int) Math.pow(1.5, 2));
        System.out.println(((double) 1 + 1 / 2)+"\t"+(1 + (double) 1 / 2));
        System.out.println((double) 5 / 3+"\t"+1.0*5/3);
        System.out.println(1 / 3+"  "+1.0/3+"  "+1.0/3+"  "+(double)1/3);
        System.out.println((double)(4/3)+ "  " + (double)4/3);
        System.out.println((int)(-20.0/3)+"  "+(int)(-20.0/3-0.5)+"  "+Math.round(-20.0/3));

    }
}
class lab1 {
    public static void main(String[] args){
        int a1=78,a2=80,a3=77;
        double average=(double)(a1+a2+a3)/3;
        double variance=(Math.pow(a1-average,2)+Math.pow(a2-average,2)+Math.pow(a3-average,2))/3;
        double deviation=Math.sqrt(variance);
        System.out.println(average+"\n"+variance+"\n"+deviation);
    }
}
class Statistics {
    public double[] num_a;
    public ArrayList<Double> num_a_list;
    private double average=0,variance=0,deviation=0;
    public Statistics(double[] num){
        num_a=num;
    }
    public Statistics(ArrayList<Double> num){
        num_a_list=num;
        double[] num_temp=new double[num_a_list.size()];
        for(int i=0;i<num_a_list.size();i++){
            num_temp[i]=num_a_list.get(i);
        }
        num_a=num_temp;
    }
    public double averagef(){
        for(int i=0;i<num_a.length;i++){
            average+=num_a[i];
        }
        average/=num_a.length;
        return average;
    }
    public double variancef(){
        for(int i=0;i<num_a.length;i++){
            variance+=Math.pow(num_a[i]-average,2);
        }
        variance/=num_a.length;
        return variance;
    }
    public double deviationf(){
        deviation=Math.sqrt(variance);
        return deviation;
    }
}
class lab1_2 {
    public static void main(String[] args){
        double[] num1= {78,80,77};
        Statistics s=new Statistics(num1);
        System.out.println(s.averagef()+"  "+s.variancef()+"  "+s.deviationf());
        ArrayList<Double> num_list=new ArrayList<>();
        num_list.add(78.0);num_list.add(80.0);num_list.add(77.0);
        //Collections.addAll(num_list,78.0,80.0,77.0);
        Statistics s2=new Statistics(num_list);
        System.out.println(s2.averagef()+"  "+s2.variancef()+"  "+s2.deviationf());
    }
}
class lab2 {
    public static void main(String[] args){
        int num=137;
        System.out.println(num/25+" quarters, "+num%25/10+" dimes, "+num%25%10/5+" nickels, "
                +num%25%10%5+" pennies.");
    }
}

