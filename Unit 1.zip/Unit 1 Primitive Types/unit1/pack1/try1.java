package pack1;

public class try1 {
    int add2(double a, double b){
        return (int)(a+b);
    }
    public int add1(double a, double b){
        return (int)(a+b);
    }

    public static void print1( ){
        System.out.println("Hello world!");
    }

}
